"""08 — Quantum Bridge: Same Math, Different Domain

The same Lars Logic that solves Sudoku also simulates quantum circuits.
You'll learn:
  - Stabilizer tableau: quantum states as GF(2) matrices
  - Quantum gates as column operations
  - Entanglement as algebraic correlation
  - Measurement as Gaussian elimination

Author: Lars Rocha — March 2026
"""
from lars_logic import (
    StabilizerTableau, LarsSolver,
    from_quantum_circuit, bell_pair, ghz_state,
)

print("=" * 60)
print("08 — Quantum Bridge: Same Math, Different Domain")
print("=" * 60)
print()

# ─── Bell State: Entanglement in 2 lines ──────────────────────
print("═══ Bell State (2 qubits) ═══")
tab = StabilizerTableau(2)
tab.h(0).cnot(0, 1)  # H on qubit 0, then CNOT 0→1

cs = tab.to_constraint_system()
result = LarsSolver(cs).solve()
print(f"  Variables: {result.n_vars} (2 qubits × 2 = X0,X1,Z0,Z1)")
print(f"  Rank: {result.rank}")
print(f"  Free: {len(result.free)} (entangled degrees of freedom)")
print(f"  Forced: {result.forced}")
print()
print("  Free variables spanning both qubits = ENTANGLEMENT")
print("  No measurement shots needed. One solve. Algebraic proof.")
print()

# ─── Measurement Collapse ─────────────────────────────────────
print("═══ Measurement Collapse ═══")
tab2 = StabilizerTableau(2)
tab2.h(0).cnot(0, 1)

out0, random0 = tab2.measure(0, outcome=0)
print(f"  Measure qubit 0: outcome={out0}, random={random0}")

out1, random1 = tab2.measure(1)
print(f"  Measure qubit 1: outcome={out1}, random={random1}")
print(f"  Qubit 1 is DETERMINISTIC after measuring qubit 0.")
print(f"  Both qubits agree: {out0} == {out1}")
print()

# ─── GHZ State: N-qubit entanglement ──────────────────────────
print("═══ GHZ State (10 qubits) ═══")
gates = ghz_state(list(range(10)))
cs_ghz = from_quantum_circuit(gates, n_qubits=10)
result_ghz = LarsSolver(cs_ghz).solve()
print(f"  Variables: {result_ghz.n_vars}")
print(f"  Rank: {result_ghz.rank}")
print(f"  Free: {len(result_ghz.free)}")
print(f"  All 10 qubits entangled in one algebraic group.")
print()

# ─── The Bridge ───────────────────────────────────────────────
print("═══ The Bridge ═══")
print()
print("  Sudoku:")
print("    Puzzle → ConstraintSystem.from_sudoku() → LarsSolver → verified")
print()
print("  Quantum:")
print("    Circuit → from_quantum_circuit() → LarsSolver → verified")
print()
print("  LDPC:")
print("    Syndrome → ConstraintSystem.from_ldpc() → LarsSolver → verified")
print()
print("  Same solver. Same algebra. Same verification.")
print("  Different domains. Oracle Algebra doesn't care what the problem is.")
