"""09 — Integrity Guard: Catch Cosmic Bit Flips

Your RAM lies to you ~3-5 times per day at altitude.
The IntegrityGuard catches it. You'll learn:
  - How to enable inline verification
  - How canary puzzles detect state corruption
  - How self-correction tracking works
  - How to log diagnostics for post-mortem analysis

Author: Lars Rocha — March 2026
"""
from lars_logic import IntegrityGuard, verify_sudoku

print("=" * 60)
print("09 — Integrity Guard: Catch Cosmic Bit Flips")
print("=" * 60)
print()

# ─── The Problem ───────────────────────────────────────────────
print("The Problem:")
print("  At 6,000 feet with non-ECC DDR4 RAM:")
print("  ~3-5 undetected bit flips per day")
print("  Most hit unused memory (harmless)")
print("  Some hit live solver state (silent corruption)")
print("  Your solver returns wrong answers. No crash. No error.")
print()

# ─── The Solution ──────────────────────────────────────────────
print("The Solution: IntegrityGuard")
print()

guard = IntegrityGuard(
    enabled=True,
    canary_interval=5,      # check canary every 5 results (demo)
    verify_all=True,
    halt_on_corruption=False,  # log and continue
)

# Set up a canary — known puzzle with known answer
canary_puzzle = '534678912672195348198342567859761423426853791713924856961537284287419635345286179'
guard.set_canary(
    canary_puzzle,
    canary_puzzle,  # it's already solved
    solver_fn=lambda p: {'board': p, 'success': True, 'technique_counts': {'x': 1}},
)

# ─── Simulate good results ────────────────────────────────────
print("Simulating 10 good results...")
good_result = {'success': True, 'technique_counts': {'nakedSingle': 5},
               'board': canary_puzzle}

for i in range(10):
    ok = guard.check(f'puzzle_{i}', good_result)

print(f"  Checked: {guard.total_checked}")
print(f"  Verified: {guard.total_verified}")
print(f"  Corruptions: {len(guard.corruption_events)}")
print()

# ─── Simulate corruption ──────────────────────────────────────
print("Simulating 5 corrupted results (empty solver output)...")
empty_result = {'success': False, 'technique_counts': {}}

for i in range(5):
    ok = guard.check(f'corrupt_{i}', empty_result)
    if not ok:
        print(f"  CAUGHT: corruption at check {guard.total_checked}")

print()

# ─── Simulate self-correction ─────────────────────────────────
print("Simulating recovery (good result after corruption)...")
ok = guard.check('recovered', good_result)
print()

# ─── Summary ───────────────────────────────────────────────────
print(guard.summary())
print()
print("The same math that corrects quantum errors")
print("corrects classical hardware errors.")
print("Your solver IS the quantum computer.")
print("Your RAM is the noisy channel.")
print("The IntegrityGuard is the syndrome check.")
