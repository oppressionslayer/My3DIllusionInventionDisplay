"""02 — Sudoku → GF(2): Turn a Puzzle Into Algebra

This is where Sudoku meets Lars Logic. You'll learn:
  - How a Sudoku puzzle becomes a GF(2) constraint system
  - How two-phase Lars complement decomposes by box
  - What Phase 1 (block-local) and Phase 2 (cross-block) mean
  - How full_solution() reconstructs every variable

Author: Lars Rocha — March 2026
"""
from lars_logic import ConstraintSystem, LarsSolver
from lars_logic.extract import superposition_report

print("=" * 60)
print("02 — Sudoku → GF(2)")
print("=" * 60)
print()

# ─── A hard puzzle from the forum hardest set ──────────────────
puzzle = '98.7..6..75..4......3..8.7.5....7.3...94.........2.1..3.......1.9...5.8...52....6'
print(f"Puzzle: {puzzle}")
print()

# Pretty print the puzzle
for r in range(9):
    row = puzzle[r*9:(r+1)*9].replace('0', '.').replace('.', '·')
    if r % 3 == 0 and r > 0:
        print("  ------+-------+------")
    cells = ' '.join(row[c] if c % 3 != 0 or c == 0 else f'| {row[c]}' for c in range(9))
    print(f"  {cells}")
print()

# ─── Convert to GF(2) ─────────────────────────────────────────
print("Converting to GF(2)...")
cs = ConstraintSystem.from_sudoku(puzzle)
print(f"  Variables: {cs.n_vars}")
print(f"  Constraints: {len(cs.rows)}")
print(f"  Blocks: {len(cs.block_bounds)} (one per Sudoku box)")
print()

# ─── Solve with two-phase Lars complement ──────────────────────
print("Solving with two-phase Lars complement...")
solver = LarsSolver(cs)
result = solver.solve()
print()
print(superposition_report(result))
print()

# ─── What this tells us ───────────────────────────────────────
print(f"Phase 1 resolved {result.phase1_pivots} variables (block-local)")
print(f"Phase 2 resolved {result.phase2_pivots} variables (cross-block)")
print(f"Total rank: {result.rank}")
print(f"Free variables: {len(result.free)} (need techniques to resolve)")
print()

# ─── Full solution at free=0 ──────────────────────────────────
solution = result.full_solution()
print(f"Full solution: {len(solution)} variables assigned")
print()

# ─── Map forced variables back to Sudoku cells ────────────────
if hasattr(cs, 'var_map'):
    placements = {}
    for var_idx, val in result.forced.items():
        if val == 1 and var_idx in cs.var_map:
            pos, digit = cs.var_map[var_idx]
            placements[pos] = digit + 1

    print(f"Cells determined by algebra alone: {len(placements)}")
    print(f"Remaining cells need techniques: {81 - 25 - len(placements)}")
    print()
    print("The GF(2) algebra gives you the LINEAR skeleton.")
    print("SIRO, harmonics, and oracles fill in the rest.")
