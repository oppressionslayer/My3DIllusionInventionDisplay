"""06 — Bootstrap Verification: Prove It Without the Answer

You'll learn:
  - How to verify predictions without knowing the solution
  - The hide-and-resolve pattern: remove known values, re-solve
  - If the solver recovers the hidden values, the oracle is verified
  - This works on ANY constraint system, not just Sudoku

Author: Lars Rocha — March 2026
"""
from lars_logic import ConstraintSystem, LarsSolver
from lars_logic.bootstrap import BootstrapVerifier, BootstrapResult

print("=" * 60)
print("06 — Bootstrap Verification")
print("=" * 60)
print()

# ─── Build a fully determined system ──────────────────────────
# 10 variables, 10 constraints → unique solution
import numpy as np
rng = np.random.default_rng(42)

# Generate a system with full GF(2) rank
while True:
    A = rng.integers(0, 2, size=(10, 10))
    cs_check = ConstraintSystem.from_gf2_matrix(A)
    r_check = LarsSolver(cs_check).solve()
    if r_check.rank == 10:
        break

b = rng.integers(0, 2, size=10)
cs = ConstraintSystem.from_gf2_matrix(A, b)
result = LarsSolver(cs).solve()

print(f"System: {A.shape[0]}×{A.shape[1]}, rank={result.rank}")
print(f"Forced: {len(result.forced)} variables (all determined)")
print(f"Solution: {result.forced}")
print()

# ─── Bootstrap verify ─────────────────────────────────────────
print("Running bootstrap verification...")
print("  1. Solve the full system → get all forced values")
print("  2. Hide a control group (some forced values)")
print("  3. Substitute all OTHER known values into a reduced system")
print("  4. Re-solve the reduced system")
print("  5. Check: did re-solve recover the hidden values?")
print()

verifier = BootstrapVerifier()
boot_result = verifier.verify(cs, partition_fn=lambda v: v % 3, min_control=2)

print(f"Verified: {boot_result.verified}")
print(f"Control variables: {boot_result.control_vars}")
print(f"Predictions: {boot_result.predictions}")
print(f"Expected: {boot_result.expected}")
print(f"Matches: {boot_result.matches}/{boot_result.total}")
print()

if boot_result.verified:
    print("VERIFIED — the solver proved its own correctness.")
    print("No answer key needed. No external oracle.")
    print("The algebra verified itself.")
else:
    print("NOT VERIFIED — insufficient forced variables or control group too small.")

print()
print("This is self-verification. The same pattern works for:")
print("  - Sudoku: hide cells, re-solve, check recovery")
print("  - Cancer research: hide patient outcomes, re-predict, check accuracy")
print("  - Any domain: hide known values, re-solve, verify")
