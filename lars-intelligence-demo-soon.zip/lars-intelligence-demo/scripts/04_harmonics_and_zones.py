"""04 — Harmonics & Zones: Where Numbers Feel Natural

You'll learn:
  - How harmonic distance measures alignment to mathematical grids
  - How closeness scores proximity to the base score
  - How zone classification splits candidates into "likely" and "unlikely"
  - Why numbers that fit harmonic grids predict better

Author: Lars Rocha — March 2026
"""
from larsdoku_zs.engine import BitBoard
from larsdoku_zs.wsrf_zone import compute_likely_map

print("=" * 60)
print("04 — Harmonics & Zones")
print("=" * 60)
print()

# ─── Load puzzle ───────────────────────────────────────────────
puzzle = '98.7..6..75..4......3..8.7.5....7.3...94.........2.1..3.......1.9...5.8...52....6'
bb = BitBoard.from_string(puzzle)

# ─── Compute the likely map ───────────────────────────────────
# threshold=3 → ratio_threshold = 1.0
# mcl=7 → max cell limit (cells with ≤7 candidates are "likely")
likely_map = compute_likely_map(bb, threshold=3, mcl=7)

print("Zone classification for first 5 empty cells:")
print()

shown = 0
for pos in sorted(likely_map.keys()):
    if shown >= 5:
        break
    r, c = pos // 9, pos % 9
    candidates = likely_map[pos]

    print(f"Cell R{r+1}C{c+1} ({len(candidates)} candidates):")
    print(f"  {'Digit':<7} {'Zone':<10} {'MinRatio':<10} {'Harmonic':<10} {'Closeness':<10} {'BaseScore':<10}")
    print(f"  {'-'*57}")

    for info in candidates:
        d = info['d']
        zone = info['zone']
        mr = info.get('minRatio', 0)
        hd = info.get('harmonicDist', 0)
        bs = info.get('baseScore', 0)
        closeness = abs(d - bs)

        print(f"  {d:<7} {zone:<10} {mr:<10.4f} {hd:<10.4f} {closeness:<10.4f} {bs:<10.4f}")

    # The rank-1 (first in sorted list) is the harmonics prediction
    rank1 = candidates[0]
    print(f"  → Rank-1: digit {rank1['d']} (zone={rank1['zone']})")
    print()
    shown += 1

# ─── Explain the formulas ─────────────────────────────────────
print("How it works:")
print("  min_ratio = tightest constraint ratio (fewer rivals = tighter)")
print("  harmonic_dist = distance from nearest grid point (N=20)")
print("    → md = min_ratio × digit")
print("    → nearest = round(md × 20) / 20")
print("    → harmonic_dist = |md - nearest|")
print("  base_score = min_ratio × 9 + cell_size - sum_ratio × 0.25")
print("  closeness = |digit - base_score|")
print()
print("Numbers that align to harmonic grids predict better.")
print("This is Oracle Algebra — the math finds the resonance.")
