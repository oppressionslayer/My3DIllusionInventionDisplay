"""10 — Fraud Detection Oracle: Lars Logic on Real-World Data

Same Oracle Algebra, different domain. You'll learn:
  - How to model transaction fraud as a GF(2) constraint system
  - How constraint groups work for non-Sudoku problems
  - How forced variables = provably fraudulent transactions
  - How free variables = ambiguous cases needing investigation

This is what lars-siro will do generically. Here we show it
with lars-logic directly on a synthetic fraud dataset.

Author: Lars Rocha — March 2026
"""
import numpy as np
from lars_logic import ConstraintSystem, LarsSolver, verify_solution

print("=" * 60)
print("10 — Fraud Detection Oracle")
print("=" * 60)
print()

# ─── Generate synthetic transaction data ───────────────────────
# 100 transactions, each with binary features:
#   - high_amount (>$500)
#   - foreign_country
#   - unusual_time (2am-5am)
#   - new_merchant
#   - velocity_spike (3+ transactions in 1 hour)
#   - card_not_present
#   - mismatched_zip
#   - repeat_decline

rng = np.random.default_rng(42)
n_transactions = 100
n_features = 8

feature_names = [
    'high_amount', 'foreign_country', 'unusual_time', 'new_merchant',
    'velocity_spike', 'card_not_present', 'mismatched_zip', 'repeat_decline'
]

# Generate features (some correlated — fraud patterns cluster)
features = rng.integers(0, 2, size=(n_transactions, n_features))

# Inject fraud patterns: if velocity_spike AND card_not_present AND high_amount → fraud
fraud_labels = np.zeros(n_transactions, dtype=int)
for i in range(n_transactions):
    if features[i, 0] and features[i, 4] and features[i, 5]:  # high + velocity + CNP
        fraud_labels[i] = 1
    if features[i, 1] and features[i, 2] and features[i, 6]:  # foreign + unusual + zip
        fraud_labels[i] = 1

n_fraud = fraud_labels.sum()
print(f"Synthetic dataset: {n_transactions} transactions, {n_fraud} fraudulent")
print(f"Features: {feature_names}")
print()

# ─── Model as GF(2) constraint system ─────────────────────────
# Each fraud rule becomes a LarsXOR constraint:
# Rule 1: high_amount ⊕ velocity_spike ⊕ card_not_present = pattern indicator
# Rule 2: foreign ⊕ unusual_time ⊕ mismatched_zip = pattern indicator
#
# We encode: for each transaction, the feature combination XOR should
# match the fraud label. This creates a GF(2) system.

print("═══ Building GF(2) Constraint System ═══")

# Create constraint matrix: each row is a fraud detection rule applied
# to a transaction. Variables = transaction fraud labels.
# Constraint: feature_pattern ⊕ fraud_label should be consistent.

# Approach: use feature patterns as constraint rows
# Group transactions by their feature fingerprint
from collections import defaultdict

fingerprints = defaultdict(list)
for i in range(n_transactions):
    fp = tuple(features[i])
    fingerprints[fp].append(i)

# Build constraints: transactions with SAME fingerprint must have SAME label
# This is a pairwise XOR constraint: label_i ⊕ label_j = 0 (same fingerprint → same label)
cs = ConstraintSystem(n_vars=n_transactions)
constraint_count = 0

for fp, indices in fingerprints.items():
    for k in range(1, len(indices)):
        # label[indices[0]] ⊕ label[indices[k]] = 0 (must match)
        cs.add_larsxor([indices[0], indices[k]], rhs=0)
        constraint_count += 1

# Add known fraud labels as constraints (training data)
# Use first 70% as training, predict last 30%
train_size = 70
for i in range(train_size):
    # Single variable constraint: label_i = fraud_labels[i]
    cs.add_larsxor([i], rhs=fraud_labels[i])

print(f"  Variables: {cs.n_vars} (one per transaction)")
print(f"  Constraints: {len(cs.rows)}")
print(f"  Fingerprint groups: {len(fingerprints)}")
print(f"  Training labels: {train_size}")
print()

# ─── Solve ─────────────────────────────────────────────────────
print("═══ Solving with LarsSolver ═══")
result = LarsSolver(cs).solve()
solution = result.full_solution()

print(f"  Rank: {result.rank}")
print(f"  Forced: {len(result.forced)} (provably determined)")
print(f"  Free: {len(result.free)} (ambiguous — need investigation)")
print(f"  Contradiction: {result.contradiction}")
print()

# ─── Evaluate on test set ──────────────────────────────────────
print("═══ Predictions on Test Set (last 30 transactions) ═══")
correct = 0
total = 0
forced_correct = 0
forced_total = 0

print(f"{'Trans':<8} {'Predicted':<10} {'Actual':<8} {'Status':<12} {'Correct':<8}")
print("-" * 50)

for i in range(train_size, n_transactions):
    predicted = solution.get(i, 0)
    actual = fraud_labels[i]
    is_forced = i in result.forced
    status = "FORCED" if is_forced else "free"
    is_correct = predicted == actual
    mark = "✓" if is_correct else "✗"

    if is_correct:
        correct += 1
    total += 1
    if is_forced:
        forced_total += 1
        if is_correct:
            forced_correct += 1

    if i < train_size + 10:  # show first 10
        print(f"  T{i:<5} {predicted:<10} {actual:<8} {status:<12} {mark}")

if total > 10:
    print(f"  ... ({total - 10} more)")

print()
print(f"Overall test accuracy: {correct}/{total} ({correct/total*100:.1f}%)")
if forced_total > 0:
    print(f"Forced predictions: {forced_correct}/{forced_total} "
          f"({forced_correct/forced_total*100:.1f}%) — algebraically proven")
print(f"Free (ambiguous): {total - forced_total} — need manual review")
print()

# ─── The Insight ───────────────────────────────────────────────
print("═══ The Insight ═══")
print()
print("FORCED variables are PROVEN by algebra:")
print("  → These transactions are provably fraud/not-fraud")
print("  → No ML model uncertainty. No probability threshold.")
print("  → The constraint system forces the answer.")
print()
print("FREE variables are genuinely ambiguous:")
print("  → The constraints don't determine these transactions")
print("  → These are the ones that need human investigation")
print("  → ML models can focus HERE instead of guessing everywhere")
print()
print("This is Oracle Algebra applied to fraud detection.")
print("The same math. The same solver. Different domain.")
print("lars-siro will make this a pip install away.")
