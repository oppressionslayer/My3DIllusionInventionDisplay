"""07 — Full Oracle Pipeline: Puzzle → Score → Oracle → Verify

The complete pipeline that uses EVERYTHING. You'll see:
  - GF(2) algebra (lars-logic) for the linear skeleton
  - SIRO scoring (larsdoku-zs) for predictions
  - Harmonics for zone classification
  - Cross-digit oracles for forced values
  - DeepResonance for the hardest eliminations
  - Full solution verification

Author: Lars Rocha — March 2026
"""
from larsdoku_zs.engine import BitBoard
from larsdoku_zs.siro_boost import siro_predict
from larsdoku_zs.wsrf_zone import compute_likely_map, sir_find_cross_digit_oracles
from larsdoku_zs.solver import solve_selective
from lars_logic import ConstraintSystem, LarsSolver, verify_solution
import numpy as np
import time

print("=" * 60)
print("07 — Full Oracle Pipeline")
print("=" * 60)
print()

puzzle = '98.7..6..75..4......3..8.7.5....7.3...94.........2.1..3.......1.9...5.8...52....6'
print(f"Puzzle: {puzzle}")
print()

# ─── Layer 1: GF(2) Algebra (Lars Logic) ──────────────────────
print("═══ Layer 1: GF(2) Lars Complement ═══")
t0 = time.perf_counter()
cs = ConstraintSystem.from_sudoku(puzzle)
gf2_result = LarsSolver(cs).solve()
gf2_time = (time.perf_counter() - t0) * 1000
print(f"  {cs.n_vars} variables, {len(cs.rows)} constraints, {len(cs.block_bounds)} blocks")
print(f"  Phase 1: {gf2_result.phase1_pivots} pivots (block-local)")
print(f"  Phase 2: {gf2_result.phase2_pivots} pivots (cross-block)")
print(f"  Rank: {gf2_result.rank}, Free: {len(gf2_result.free)}")
print(f"  Time: {gf2_time:.1f}ms")
print()

# ─── Layer 2: SIRO Scoring ─────────────────────────────────────
print("═══ Layer 2: SIRO Predictions ═══")
bb = BitBoard.from_string(puzzle)
t0 = time.perf_counter()
predictions = siro_predict(bb)
siro_time = (time.perf_counter() - t0) * 1000
print(f"  {len(predictions)} cells scored")
print(f"  Time: {siro_time:.1f}ms")
print()

# ─── Layer 3: Harmonics & Zones ────────────────────────────────
print("═══ Layer 3: Harmonics & Zones ═══")
t0 = time.perf_counter()
likely_map = compute_likely_map(bb, threshold=3, mcl=7)
harm_time = (time.perf_counter() - t0) * 1000
likely_count = sum(1 for pos in likely_map
                   for info in likely_map[pos] if info['zone'] == 'likely')
unlikely_count = sum(1 for pos in likely_map
                     for info in likely_map[pos] if info['zone'] == 'unlikely')
print(f"  Likely candidates: {likely_count}")
print(f"  Unlikely candidates: {unlikely_count}")
print(f"  Time: {harm_time:.1f}ms")
print()

# ─── Layer 4: Cross-Digit Oracles ──────────────────────────────
print("═══ Layer 4: Cross-Digit Oracles ═══")
t0 = time.perf_counter()
oracles = sir_find_cross_digit_oracles(bb, likely_map)
oracle_time = (time.perf_counter() - t0) * 1000
print(f"  Found {len(oracles)} oracles (100% accuracy)")
for o in oracles[:3]:
    r, c = o['pos'] // 9, o['pos'] % 9
    print(f"    R{r+1}C{c+1} = {o['digit']}")
if len(oracles) > 3:
    print(f"    ... and {len(oracles) - 3} more")
print(f"  Time: {oracle_time:.1f}ms")
print()

# ─── Layer 5: Full Solve with DeepResonance ────────────────────
print("═══ Layer 5: Full Solve (DeepResonance) ═══")
t0 = time.perf_counter()
result = solve_selective(puzzle)
solve_time = (time.perf_counter() - t0) * 1000
success = result.get('success', False)
stalled = result.get('stalled', True)
techs = {k: v for k, v in result.get('technique_counts', {}).items() if v > 0}
board = result.get('board', '')
print(f"  Success: {success}, Stalled: {stalled}")
print(f"  Techniques used: {techs}")
print(f"  Time: {solve_time:.1f}ms")
print()

# ─── Layer 6: Verify ───────────────────────────────────────────
print("═══ Layer 6: Verification ═══")
if board and len(board) == 81:
    # Verify all rows, cols, boxes
    valid = True
    for r in range(9):
        if len(set(board[r*9:(r+1)*9])) != 9:
            valid = False
    for c in range(9):
        if len(set(board[c::9])) != 9:
            valid = False
    for br in range(3):
        for bc in range(3):
            box = ''.join(board[(br*3+r)*9+bc*3+c] for r in range(3) for c in range(3))
            if len(set(box)) != 9:
                valid = False
    print(f"  Solution valid: {valid}")
    print(f"  Board: {board}")
print()

# ─── Summary ───────────────────────────────────────────────────
print("═══ Pipeline Summary ═══")
print(f"  GF(2) algebra:     {gf2_time:>7.1f}ms (rank={gf2_result.rank})")
print(f"  SIRO scoring:      {siro_time:>7.1f}ms ({len(predictions)} cells)")
print(f"  Harmonics:         {harm_time:>7.1f}ms ({likely_count} likely)")
print(f"  Cross-digit oracle:{oracle_time:>7.1f}ms ({len(oracles)} found)")
print(f"  Full solve:        {solve_time:>7.1f}ms (DeepResonance)")
total_time = gf2_time + siro_time + harm_time + oracle_time + solve_time
print(f"  Total:             {total_time:>7.1f}ms")
print()
print("Every layer adds intelligence. Together they solve the unsolvable.")
