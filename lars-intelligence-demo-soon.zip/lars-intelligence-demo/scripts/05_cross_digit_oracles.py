"""05 — Cross-Digit Oracles: 100% Accuracy Forced Values

This is the crown jewel. You'll learn:
  - How cross-constraint agreement forces values
  - Why GZR ≥ 2 + paired == 1 = oracle (100% accuracy)
  - How this is pure logic, not prediction
  - How to find oracles in any constraint system

Author: Lars Rocha — March 2026
"""
from larsdoku_zs.engine import BitBoard
from larsdoku_zs.wsrf_zone import compute_likely_map, sir_find_cross_digit_oracles
from larsdoku_zs.solver import solve_selective

print("=" * 60)
print("05 — Cross-Digit Oracles (100% Accuracy)")
print("=" * 60)
print()

# ─── Load puzzle and get solution ──────────────────────────────
puzzle = '98.7..6..75..4......3..8.7.5....7.3...94.........2.1..3.......1.9...5.8...52....6'
bb = BitBoard.from_string(puzzle)
solution_result = solve_selective(puzzle)
solution = solution_result.get('board', '')

# ─── Compute zone map ──────────────────────────────────────────
likely_map = compute_likely_map(bb, threshold=3, mcl=7)

# ─── Find cross-digit oracles ─────────────────────────────────
oracles = sir_find_cross_digit_oracles(bb, likely_map, solution=solution)

print(f"Found {len(oracles)} cross-digit oracles:")
print()

for i, oracle in enumerate(oracles):
    pos = oracle['pos']
    digit = oracle['digit']
    unit = oracle.get('unit_name', '?')
    conflicts = oracle.get('conflict_cells', [])
    r, c = pos // 9, pos % 9
    actual = int(solution[pos]) if solution else '?'
    correct = "✓" if digit == actual else "✗"

    print(f"  Oracle {i+1}: R{r+1}C{c+1} = {digit} {correct}")
    print(f"    Unit: {unit}")
    print(f"    GZR cells: {len(conflicts)} (rank-1 agreement)")
    print(f"    Pattern: {len(conflicts)} cells agree on digit {digit} as rank-1,")
    print(f"             this is the only remaining cell → FORCED")
    print()

# ─── Explain the pattern ──────────────────────────────────────
print("How cross-digit oracles work:")
print()
print("  In a constraint group (row/col/box):")
print("  1. Find cells where digit D is their rank-1 prediction (GZR cells)")
print("  2. If GZR ≥ 2 (multiple cells agree D is their top pick)")
print("  3. AND exactly 1 other cell has D as candidate but NOT rank-1")
print("  4. → That cell is FORCED to contain D")
print()
print("  This is NOT prediction. This is pure constraint logic.")
print("  The agreement of the GZR cells creates a forcing pattern.")
print("  100% accuracy because it's deduction, not estimation.")
