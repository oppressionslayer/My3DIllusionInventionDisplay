"""01 — Meet Lars Logic: Your First GF(2) Solve

This is where it all starts. You'll learn:
  - How to build a GF(2) constraint system
  - How to solve it with LarsSolver
  - How to verify the solution is correct
  - What forced vs free variables mean

Author: Lars Rocha — March 2026
"""
from lars_logic import ConstraintSystem, LarsSolver, verify_solution
import numpy as np

print("=" * 60)
print("01 — Meet Lars Logic")
print("=" * 60)
print()

# ─── Step 1: Build a simple constraint system ─────────────────
# Three binary variables: x0, x1, x2
# Two LarsXOR constraints:
#   x0 ⊕ x1 = 1  (they must differ)
#   x1 ⊕ x2 = 0  (they must match)
print("Step 1: Build constraints")
cs = ConstraintSystem(n_vars=3)
cs.add_larsxor([0, 1], rhs=1)  # x0 ⊕ x1 = 1
cs.add_larsxor([1, 2], rhs=0)  # x1 ⊕ x2 = 0
print(f"  Variables: {cs.n_vars}")
print(f"  Constraints: {len(cs.rows)}")
print()

# ─── Step 2: Solve with LarsSolver ────────────────────────────
print("Step 2: Solve")
solver = LarsSolver(cs)
result = solver.solve()
print(f"  Rank: {result.rank}")
print(f"  Forced: {result.forced}")
print(f"  Free: {result.free}")
print(f"  Contradiction: {result.contradiction}")
print()

# What this means:
# - Forced variables have proven values (algebra says so)
# - Free variables can be 0 or 1 (both valid)
# - No contradiction = the system is consistent

# ─── Step 3: Reconstruct full solution ─────────────────────────
print("Step 3: Full solution")
solution = result.full_solution()
print(f"  x0={solution[0]}, x1={solution[1]}, x2={solution[2]}")
print()

# ─── Step 4: VERIFY — the mathematical proof ──────────────────
print("Step 4: Verify (the proof)")
A = np.array([[1, 1, 0], [0, 1, 1]], dtype=int)
b = np.array([1, 0])
correct, satisfied, total = verify_solution(A, b, solution)
print(f"  H @ x mod 2 == b: {correct} ({satisfied}/{total} constraints)")
print()

# ─── Step 5: Try a bigger system ───────────────────────────────
print("Step 5: Bigger system (from a matrix)")
A_big = np.random.default_rng(42).integers(0, 2, size=(20, 30))
b_big = np.random.default_rng(42).integers(0, 2, size=20)

cs_big = ConstraintSystem.from_gf2_matrix(A_big, b_big)
result_big = LarsSolver(cs_big).solve()
solution_big = result_big.full_solution()
correct_big, sat_big, total_big = verify_solution(A_big, b_big, solution_big)

print(f"  System: {A_big.shape[0]}×{A_big.shape[1]}")
print(f"  Rank: {result_big.rank}")
print(f"  Forced: {len(result_big.forced)}, Free: {len(result_big.free)}")
print(f"  Verified: {correct_big} ({sat_big}/{total_big})")
print()
print("That's Lars Logic. Every solution verified. Press enter.")
