"""03 — SIRO Predictions: Rank Every Candidate

SIRO = Super Intelligence Ranking Oracle. You'll learn:
  - How SIRO scores each candidate by counting constraint rivals
  - How confidence is the gap between best and worst candidate
  - How test order puts likely-wrong candidates first (for fast contradiction)
  - How accuracy measures against the actual solution

Author: Lars Rocha — March 2026
"""
from larsdoku_zs.engine import BitBoard
from larsdoku_zs.siro_boost import siro_predict
from larsdoku_zs.solver import solve_selective

print("=" * 60)
print("03 — SIRO Predictions")
print("=" * 60)
print()

# ─── Load a puzzle ─────────────────────────────────────────────
puzzle = '98.7..6..75..4......3..8.7.5....7.3...94.........2.1..3.......1.9...5.8...52....6'
bb = BitBoard.from_string(puzzle)

# ─── Get the actual solution (for accuracy checking) ──────────
solution_result = solve_selective(puzzle)
solution = solution_result.get('board', '')
print(f"Puzzle has {bb.empty} empty cells")
print()

# ─── Run SIRO prediction ──────────────────────────────────────
predictions = siro_predict(bb)

print("SIRO Predictions (first 10 empty cells):")
print(f"{'Cell':<8} {'Predicted':<10} {'Confidence':<12} {'Actual':<8} {'Correct':<8}")
print("-" * 52)

correct = 0
total = 0
shown = 0
for pos in sorted(predictions.keys()):
    info = predictions[pos]
    pred_digit = info['digit']
    confidence = info['confidence']
    actual = int(solution[pos]) if solution else '?'

    is_correct = (pred_digit == actual)
    if is_correct:
        correct += 1
    total += 1

    if shown < 10:
        mark = "✓" if is_correct else "✗"
        r, c = pos // 9, pos % 9
        print(f"  R{r+1}C{c+1}   {pred_digit:<10} {confidence:<12} {actual:<8} {mark}")
        shown += 1

print(f"\nOverall SIRO accuracy: {correct}/{total} ({correct/total*100:.1f}%)")
print()

# ─── Show the scoring detail for one cell ──────────────────────
example_pos = sorted(predictions.keys())[0]
info = predictions[example_pos]
r, c = example_pos // 9, example_pos % 9
print(f"Detail for R{r+1}C{c+1}:")
print(f"  Scores (digit, rival_count): {info['scores']}")
print(f"  Predicted: digit {info['digit']} (lowest rivals = most constrained)")
print(f"  Confidence: {info['confidence']} (gap between best and worst)")
print(f"  Test order: {info['order']} (worst first — for contradiction testing)")
print()
print("SIRO doesn't guess. It counts rivals in each constraint group.")
print("Lowest rivals = tightest constraint = most likely digit.")
