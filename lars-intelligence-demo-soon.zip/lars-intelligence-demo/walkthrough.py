"""
Lars Intelligence Demo — Interactive Walkthrough
=================================================

Run this in IPython:
    ipython -i walkthrough.py

Then follow the prompts. Each section teaches you one concept.
Type the commands yourself to build muscle memory.

Author: Lars Rocha — March 2026
"""

print("""
╔══════════════════════════════════════════════════════════╗
║         Lars Intelligence Demo — Walkthrough            ║
║                                                         ║
║  Follow along. Type each command yourself.              ║
║  The magic is in understanding, not copy-paste.         ║
╚══════════════════════════════════════════════════════════╝

Ready? Let's go. Type the commands below one at a time.

═══════════════════════════════════════════════════════════
PART 1: Meet LarsSolver
═══════════════════════════════════════════════════════════

# Import the library
from lars_logic import ConstraintSystem, LarsSolver, verify_solution

# Build a tiny system: 3 variables, 2 constraints
cs = ConstraintSystem(n_vars=3)
cs.add_larsxor([0, 1], rhs=1)    # x0 ⊕ x1 = 1
cs.add_larsxor([1, 2], rhs=0)    # x1 ⊕ x2 = 0

# Solve it
result = LarsSolver(cs).solve()
print(result.forced)              # what's proven
print(result.free)                # what's undetermined

# Get the full solution
solution = result.full_solution()
print(solution)                   # all variables assigned

═══════════════════════════════════════════════════════════
PART 2: Solve a Sudoku with GF(2)
═══════════════════════════════════════════════════════════

# Hard puzzle from forum hardest set
puzzle = '98.7..6..75..4......3..8.7.5....7.3...94.........2.1..3.......1.9...5.8...52....6'

# Convert to GF(2)
cs = ConstraintSystem.from_sudoku(puzzle)
print(f"Variables: {cs.n_vars}, Blocks: {len(cs.block_bounds)}")

# Two-phase Lars complement
result = LarsSolver(cs).solve()
print(f"Phase 1: {result.phase1_pivots}, Phase 2: {result.phase2_pivots}")
print(f"Free: {len(result.free)}")

═══════════════════════════════════════════════════════════
PART 3: SIRO Predictions
═══════════════════════════════════════════════════════════

from larsdoku_zs.engine import BitBoard
from larsdoku_zs.siro_boost import siro_predict

bb = BitBoard.from_string(puzzle)
predictions = siro_predict(bb)

# Look at one cell's prediction
pos = sorted(predictions.keys())[0]
info = predictions[pos]
r, c = pos // 9, pos % 9
print(f"Cell R{r+1}C{c+1}: predicted={info['digit']}, confidence={info['confidence']}")
print(f"Scores: {info['scores']}")

═══════════════════════════════════════════════════════════
PART 4: Harmonics & Zones
═══════════════════════════════════════════════════════════

from larsdoku_zs.wsrf_zone import compute_likely_map

likely_map = compute_likely_map(bb, threshold=3, mcl=7)

# Look at zone classification for one cell
pos = sorted(likely_map.keys())[0]
for info in likely_map[pos]:
    print(f"  digit={info['d']}, zone={info['zone']}, harmonic={info.get('harmonicDist',0):.4f}")

═══════════════════════════════════════════════════════════
PART 5: Cross-Digit Oracles (100% Accuracy)
═══════════════════════════════════════════════════════════

from larsdoku_zs.wsrf_zone import sir_find_cross_digit_oracles

oracles = sir_find_cross_digit_oracles(bb, likely_map)
print(f"Found {len(oracles)} oracles")
for o in oracles[:3]:
    r, c = o['pos'] // 9, o['pos'] % 9
    print(f"  R{r+1}C{c+1} = {o['digit']} (100% forced)")

═══════════════════════════════════════════════════════════
PART 6: Bootstrap Verify
═══════════════════════════════════════════════════════════

from lars_logic.bootstrap import BootstrapVerifier
import numpy as np

# Build a fully determined system
A = np.eye(5, dtype=int)
b = np.array([1, 0, 1, 0, 1])
cs = ConstraintSystem.from_gf2_matrix(A, b)

verifier = BootstrapVerifier()
boot = verifier.verify(cs, partition_fn=lambda v: v % 2)
print(f"Verified: {boot.verified}")

═══════════════════════════════════════════════════════════
PART 7: Quantum Bridge
═══════════════════════════════════════════════════════════

from lars_logic import StabilizerTableau, from_quantum_circuit, bell_pair

# Bell state in 2 lines
cs = from_quantum_circuit(bell_pair(0, 1), n_qubits=2)
result = LarsSolver(cs).solve()
print(f"Entangled: {len(result.free)} free variables (= entanglement)")

# Measure
tab = StabilizerTableau(2)
tab.h(0).cnot(0, 1)
out0, rand0 = tab.measure(0, outcome=0)
out1, rand1 = tab.measure(1)
print(f"Qubit 0: {out0} (random={rand0})")
print(f"Qubit 1: {out1} (random={rand1}) — determined by qubit 0")

═══════════════════════════════════════════════════════════
PART 8: Fraud Detection (Non-Sudoku!)
═══════════════════════════════════════════════════════════

# Run the full fraud detection demo
exec(open('scripts/10_fraud_detection_oracle.py').read())

═══════════════════════════════════════════════════════════
DONE! You just used:
  - LarsSolver (GF(2) engine)
  - SIRO predictions (constraint scoring)
  - Harmonics & zones (resonance math)
  - Cross-digit oracles (100% forced values)
  - Bootstrap verification (self-proof)
  - Quantum bridge (stabilizer → constraints)
  - Fraud detection (non-Sudoku domain)

All from the same ecosystem. Oracle Algebra.
═══════════════════════════════════════════════════════════
""")
