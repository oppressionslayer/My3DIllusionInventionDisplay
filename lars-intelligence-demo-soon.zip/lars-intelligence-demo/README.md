# Lars Intelligence Demo — Build a Sudoku Oracle

**Learn to build an Oracle from scratch using the Lars ecosystem.**

This project walks you through every step of building a Sudoku oracle
using `lars-logic` (the GF(2) engine) and `larsdoku-zs` (the Sudoku
solver). By the end, you'll understand how to apply these techniques
to ANY constraint satisfaction problem.

## The Lars Ecosystem

```
larsdoku-zs       = Sudoku solver (35 techniques, SIRO, zones, DeepResonance)
lars-logic        = GF(2) engine (LarsSolver, stabilizer, quantum gates)
lars-siro (soon)  = Generic oracle toolkit (for any domain)
```

## Scripts (Follow In Order)

| Script | What You Learn |
|--------|---------------|
| `01_meet_lars_logic.py` | LarsSolver basics — build constraints, solve, verify |
| `02_sudoku_to_gf2.py` | Convert a Sudoku puzzle to GF(2) and solve with Lars complement |
| `03_siro_predictions.py` | SIRO scoring — predict which digit goes where |
| `04_harmonics_and_zones.py` | Harmonic distance, closeness, zone classification |
| `05_cross_digit_oracles.py` | Find forced values with 100% accuracy |
| `06_bootstrap_verify.py` | Self-verify predictions without the answer key |
| `07_full_oracle_pipeline.py` | End-to-end: puzzle → score → oracle → boost → verify |
| `08_quantum_bridge.py` | Same math works for quantum circuits |
| `09_integrity_guard.py` | Detect cosmic bit flips in long runs |
| `10_batch_solve_48k.py` | Solve 48,765 hardest puzzles with verification |

## Interactive Walkthrough

```bash
# Start IPython and follow along
ipython -i walkthrough.py
```

## Install Dependencies

```bash
pip install lars-logic larsdoku-zs
```

## Author

Lars Rocha — March 2026
Oracle Algebra. Press enter.
